# My Valentine 

A Pen created on CodePen.io. Original URL: [https://codepen.io/ZPC13/pen/LYaMyKx](https://codepen.io/ZPC13/pen/LYaMyKx).

Another year, Another pen for valentines day. 

I'm using this awesome Css Gradient Pattern of Lea Verou's Gallery:
http://lea.verou.me/css3patterns/#hearts
 By the way I like her a lot :D 

___________

Also Here is my previous Valentine's pen:
http://codepen.io/AngelaVelasquez/details/KqCDz/